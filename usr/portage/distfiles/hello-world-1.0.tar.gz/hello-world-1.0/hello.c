#include <stdio.h>

int main(int argc, char **argv)
{
	printf("hello my first ebuild\n");
	return 0;
}
